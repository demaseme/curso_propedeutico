#encoding: utf-8

#Patron 1, la n especifica la altura del triángulo. Debe ser mayor o igual a 7 

import sys
if len(sys.argv) != 2 :
	print 'Args: número'
	sys.exit(2)
n = int(sys.argv[1])
if n < 7 :
	print 'El primer argumento debe ser mayor o igual a 7'
	sys.exit(1)
i = 0
j = n
c = 0
while i < n :
	while c >= 0:
		print '*',
		c-=1
	i+=1
	c = i
	print
c = i - 1
while i >= 0 :
	while c > 0:
		print '*',
		c-=1
	i-=1
	c = i - 1
	print
